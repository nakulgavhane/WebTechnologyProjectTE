<footer>
	<div class="col-sm-12">
		<p class="back-link"> <?php echo date("Y"); ?> - WT PROJECT 2023 </p>
	</div>
</footer>